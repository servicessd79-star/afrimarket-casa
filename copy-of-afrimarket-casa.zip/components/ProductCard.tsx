
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onOrder: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onOrder }) => {
  return (
    <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden flex flex-col group transition-all hover:shadow-lg">
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover transition-transform group-hover:scale-110"
        />
        <div className="absolute top-3 left-3">
          <span className="bg-black/50 backdrop-blur-md text-white text-[10px] px-2 py-1 rounded-full uppercase font-bold tracking-wider">
            {product.category}
          </span>
        </div>
      </div>
      
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="font-bold text-gray-800 text-lg mb-1">{product.name}</h3>
        <p className="text-gray-500 text-sm line-clamp-2 mb-4 flex-grow">{product.description}</p>
        
        <div className="flex items-center justify-between mt-auto">
          <div className="text-xl font-black text-green-800">
            {product.price} <span className="text-xs font-normal">MAD</span>
          </div>
          <button 
            onClick={onOrder}
            className="bg-green-700 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-md hover:bg-green-800 active:scale-95 transition-all flex items-center gap-2"
          >
            Commander
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;

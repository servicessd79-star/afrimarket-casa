
import React, { useState } from 'react';
import { Product, Category, CATEGORIES } from '../types';
import ProductCard from './ProductCard';
import OrderModal from './OrderModal';

interface ShopViewProps {
  products: Product[];
  selectedCategory: Category | 'Tous';
  setSelectedCategory: (c: Category | 'Tous') => void;
  sellerWhatsApp: string;
}

const ShopView: React.FC<ShopViewProps> = ({ products, selectedCategory, setSelectedCategory, sellerWhatsApp }) => {
  const [orderingProduct, setOrderingProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = products.filter(p => {
    const query = searchQuery.toLowerCase();
    const matchesCategoryFilter = selectedCategory === 'Tous' || p.category === selectedCategory;
    
    // Search in name, description, and category
    const matchesSearch = 
      p.name.toLowerCase().includes(query) || 
      p.description.toLowerCase().includes(query) ||
      p.category.toLowerCase().includes(query);

    return matchesCategoryFilter && matchesSearch;
  });

  return (
    <div className="animate-fade-in">
      {/* Welcome Message */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 mb-6">
        <h2 className="text-yellow-800 font-bold text-lg">Bienvenue ! 👋</h2>
        <p className="text-yellow-700 text-sm">Trouvez vos produits préférés et commandez directement sur WhatsApp.</p>
      </div>

      {/* Search Bar */}
      <div className="relative mb-6">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
        <input
          type="text"
          className="block w-full pl-11 pr-4 py-3.5 border border-gray-200 rounded-2xl leading-5 bg-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-600 focus:border-transparent transition-all shadow-sm text-gray-700"
          placeholder="Rechercher (nom, catégorie, description...)"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        {searchQuery && (
          <button 
            onClick={() => setSearchQuery('')}
            className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600"
          >
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>

      {/* Categories Scroller */}
      <div className="mb-8 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 pb-2">
          <button
            onClick={() => setSelectedCategory('Tous')}
            className={`px-5 py-2.5 rounded-full whitespace-nowrap text-sm font-semibold transition-all ${
              selectedCategory === 'Tous' 
                ? 'bg-green-700 text-white shadow-md scale-105' 
                : 'bg-white text-gray-600 border border-gray-200 hover:border-green-200'
            }`}
          >
            Tous les produits
          </button>
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-5 py-2.5 rounded-full whitespace-nowrap text-sm font-semibold transition-all ${
                selectedCategory === cat 
                  ? 'bg-green-700 text-white shadow-md scale-105' 
                  : 'bg-white text-gray-600 border border-gray-200 hover:border-green-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Results Count */}
      {searchQuery && (
        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">
          {filteredProducts.length} résultat{filteredProducts.length > 1 ? 's' : ''} pour "{searchQuery}"
        </p>
      )}

      {/* Product Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map(product => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onOrder={() => setOrderingProduct(product)}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-gray-200">
          <div className="text-gray-300 mb-4">
            <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <p className="text-gray-500 font-medium">Aucun produit ne correspond à votre recherche.</p>
          <button 
            onClick={() => {setSearchQuery(''); setSelectedCategory('Tous');}}
            className="mt-4 text-green-700 font-bold text-sm underline"
          >
            Réinitialiser les filtres
          </button>
        </div>
      )}

      {/* Direct Contact Floating Button */}
      <a 
        href={`https://wa.me/${sellerWhatsApp}`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-20 right-4 bg-green-500 text-white p-4 rounded-full shadow-2xl hover:scale-110 active:scale-95 transition-all z-40 flex items-center justify-center"
      >
        <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.72.94 3.659 1.437 5.634 1.437h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
        </svg>
      </a>

      {orderingProduct && (
        <OrderModal 
          product={orderingProduct} 
          sellerWhatsApp={sellerWhatsApp}
          onClose={() => setOrderingProduct(null)} 
        />
      )}
    </div>
  );
};

export default ShopView;

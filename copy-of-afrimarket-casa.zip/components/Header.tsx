
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-gray-100 sticky top-0 z-40 px-4 py-4 shadow-sm">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 african-gradient rounded-full flex items-center justify-center text-white font-bold shadow-md">
            AM
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-800 leading-tight">AfriMarket <span className="text-green-700">Casa</span></h1>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest font-semibold">Le meilleur de l'Afrique à Casa</p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;

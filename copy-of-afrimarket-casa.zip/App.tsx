
import React, { useState, useEffect, useCallback } from 'react';
import { Product, Category, CATEGORIES } from './types';
import Header from './components/Header';
import ShopView from './components/ShopView';
import SellerView from './components/SellerView';

const LOCAL_STORAGE_KEY = 'afri-market-casa-products';
const SELLER_WHATSAPP = '212600000000'; // Default placeholder, usually configured by merchant

const App: React.FC = () => {
  const [view, setView] = useState<'shop' | 'seller'>('shop');
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category | 'Tous'>('Tous');

  // Load products from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      setProducts(JSON.parse(saved));
    } else {
      // Initial demo data
      const demoProducts: Product[] = [
        {
          id: '1',
          name: 'Huile de Baobab Pure',
          description: 'Huile 100% naturelle pour la peau et les cheveux.',
          price: 150,
          category: 'Huiles naturelles',
          image: 'https://picsum.photos/seed/baobab/400/400',
          isActive: true,
          createdAt: Date.now()
        },
        {
          id: '2',
          name: 'Boubou traditionnel',
          description: 'Coton de haute qualité, taille unique.',
          price: 450,
          category: 'Vêtements',
          image: 'https://picsum.photos/seed/dress/400/400',
          isActive: true,
          createdAt: Date.now()
        }
      ];
      setProducts(demoProducts);
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(demoProducts));
    }
  }, []);

  const saveProducts = (newProducts: Product[]) => {
    setProducts(newProducts);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newProducts));
  };

  const addProduct = (p: Omit<Product, 'id' | 'createdAt' | 'isActive'>) => {
    const newProduct: Product = {
      ...p,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: Date.now(),
      isActive: true
    };
    saveProducts([newProduct, ...products]);
  };

  const updateProduct = (updated: Product) => {
    saveProducts(products.map(p => p.id === updated.id ? updated : p));
  };

  const deleteProduct = (id: string) => {
    if (confirm('Voulez-vous vraiment supprimer ce produit ?')) {
      saveProducts(products.filter(p => p.id !== id));
    }
  };

  return (
    <div className="min-h-screen flex flex-col pb-20">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 pt-4">
        {view === 'shop' ? (
          <ShopView 
            products={products.filter(p => p.isActive)} 
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            sellerWhatsApp={SELLER_WHATSAPP}
          />
        ) : (
          <SellerView 
            products={products}
            onAdd={addProduct}
            onUpdate={updateProduct}
            onDelete={deleteProduct}
          />
        )}
      </main>

      {/* Persistent Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg flex justify-around items-center h-16 z-50">
        <button 
          onClick={() => setView('shop')}
          className={`flex flex-col items-center transition-colors ${view === 'shop' ? 'text-green-700' : 'text-gray-400'}`}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
          </svg>
          <span className="text-xs font-medium">Boutique</span>
        </button>
        <button 
          onClick={() => setView('seller')}
          className={`flex flex-col items-center transition-colors ${view === 'seller' ? 'text-green-700' : 'text-gray-400'}`}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          <span className="text-xs font-medium">Vendeur</span>
        </button>
      </nav>
    </div>
  );
};

export default App;

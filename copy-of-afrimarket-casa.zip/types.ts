
export type Category = 
  | 'Nourriture'
  | 'Vêtements'
  | 'Bijoux'
  | 'Plantes & Médicaments'
  | 'Huiles naturelles'
  | 'Beauté & Bien-être'
  | 'Autres';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  image: string; // Base64 or URL
  isActive: boolean;
  createdAt: number;
}

export interface OrderData {
  customerName: string;
  customerWhatsApp: string;
  quantity: number;
  message?: string;
}

export const CATEGORIES: Category[] = [
  'Nourriture',
  'Vêtements',
  'Bijoux',
  'Plantes & Médicaments',
  'Huiles naturelles',
  'Beauté & Bien-être',
  'Autres'
];
